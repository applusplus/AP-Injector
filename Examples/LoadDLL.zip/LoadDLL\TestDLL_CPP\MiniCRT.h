#pragma once

// We are using the Visual C++ CRT instead of the MiniCRT in the Debug-LoadLibrary configuration
// in order to be able to turn on advanced debugging features (like buffer security check, etc...).
#if !defined(NO_MINICRT) || !NO_MINICRT
	#define MINICRT_ENABLED 1
#endif

#ifdef _DEBUG
	#define DEBUG 1
#endif

#if DEBUG
	#define ASSERT_ACTIVE 1
#endif


#include <windows.h>


#if MINICRT_ENABLED

#define NULL 0

#if ASSERT_ACTIVE
	void __assert(const char* condition, const char* file, int line, const char* function);
	#define ASSERT(x) { if (!(x)) __assert(#x, __FILE__, __LINE__, __FUNCTION__); }
	#define VERIFY(x) ASSERT(x)
	#define VERIFY_EQ(val, expr) ASSERT((expr) == (val))
	#define VERIFY_NE(val, expr) ASSERT((expr) != (val))
	#define VERIFY_FALSE(x) ASSERT(!(x))
#else
	#define ASSERT(x)
	#define VERIFY(x) x
	#define VERIFY_EQ(val, expr) expr
	#define VERIFY_NE(val, expr) expr
	#define VERIFY_FALSE(x) x
#endif

// Call MiniCRTStartup() from the beginning of your DLL_PROCESS_ATTACH handler.
void __cdecl MiniCRTStartup();
// Call MiniCRTCleanup() from the beginning of your DLL_PROCESS_DETACH handler.
void __cdecl MiniCRTCleanup();

// If you don't want to define your own DllMain() just to call MiniCRTStartup() and
// MiniCRTCleanup() then tell the linker to use MiniCRTDllMain() function as the
// entrypoint of the DLL with the /ENTRY:MiniCRTDllMain parameter.
BOOL WINAPI MiniCRTDllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved);

typedef void (__cdecl*CrtInitFunc)();
int __cdecl atexit(CrtInitFunc func);

int __cdecl printf(const char* format, ...);
void* __cdecl memset(void* dst, int val, size_t count);
void* __cdecl memcpy(void* dst, const void* src, size_t count);


#else


#include <stdio.h>
#include <stdlib.h>

#if ASSERT_ACTIVE
	#include <assert.h>
	#define ASSERT(x) assert(x)
	#define VERIFY(x) ASSERT(x)
	#define VERIFY_EQ(val, expr) ASSERT((expr) == (val))
	#define VERIFY_NE(val, expr) ASSERT((expr) != (val))
	#define VERIFY_FALSE(x) ASSERT(!(x))
#else
	#define ASSERT(x)
	#define VERIFY(x) x
	#define VERIFY_EQ(val, expr) expr
	#define VERIFY_NE(val, expr) expr
	#define VERIFY_FALSE(x) x
#endif


inline void __cdecl MiniCRTStartup() {}
inline void __cdecl MiniCRTCleanup() {}


#endif

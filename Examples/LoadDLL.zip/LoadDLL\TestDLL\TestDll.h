#pragma once


typedef struct DLLInterface
{
	int (*AddNumbers)(int a, int b);
	void (*MyMessageBox)(const char* message);
} DLLInterface;

#include "TestDLL_CPP.h"
#include "MiniCRT.h"



class CDLLInterface : public I_DLLInterface
{
public:
	virtual int AddNumbers(int a, int b) override
	{
		printf("DLL_CPP: AddNumbers(%d, %d)\n", a, b);
		return a + b;
	}
	virtual void MyMessageBox(const char* message) override
	{
		printf("DLL_CPP: MyMessageBox(\"%s\")\n", message);
		MessageBoxA(NULL, message, "DLL_CPP MessageBox!", MB_OK);
	}
};

static CDLLInterface g_DLLInterface;

extern "C" __declspec(dllexport) I_DLLInterface* GetDLLInterface()
{
	return &g_DLLInterface;
}


struct SStaticInitTest
{
	int id;
	SStaticInitTest(int x=0)
	{
		id = x;
		printf("%s(%d)\n", __FUNCTION__, id);
	}
	~SStaticInitTest()
	{
		printf("%s(%d)\n", __FUNCTION__, id);
	}
};

static SStaticInitTest s1(1);
static SStaticInitTest s2(2);

struct SNewDelete
{
	int x;
};

void TestMiniCRT()
{
	int* int_arr = new int[5];
	delete[] int_arr;
	SNewDelete* p = new SNewDelete;
	delete p;
	p = new SNewDelete[2];
	delete[] p;

	char buf[5] = { 0 };
	char buf2[5] = { 2, 2, 2, 2, 2 };
	void* p0 = memset(buf+1, 1, 3);
	void* p1 = memcpy(buf2+1, buf, 2);
}


// If you don't need a DllMain then you can delete this function and then use the /NOENTRY linker option.
// In case of using /NOENTRY make sure that you specify the /ENTRY:MiniCRTDllMain linker option to
// initialize the MiniCRT library.
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	// With manual DLL loading you can not use DLL_THREAD_ATTACH and DLL_THREAD_DETACH.
	switch (fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		printf("DLL: DLL_PROCESS_ATTACH\n");
		MiniCRTStartup();
		TestMiniCRT();
		// TODO: Your code here
		break;
	case DLL_PROCESS_DETACH:
		printf("DLL: DLL_PROCESS_DETACH\n");
		// TODO: Your code here
		MiniCRTCleanup();
		break;
	default:
		break;
	}
	return TRUE;
}

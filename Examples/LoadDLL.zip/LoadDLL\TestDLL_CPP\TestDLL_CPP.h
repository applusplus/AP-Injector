#pragma once


class I_DLLInterface
{
public:
	virtual int AddNumbers(int a, int b) = 0;
	virtual void MyMessageBox(const char* message) = 0;
};

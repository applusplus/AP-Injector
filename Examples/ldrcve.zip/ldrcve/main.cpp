#include <stdio.h>
#include <Windows.h>
#include <tlhelp32.h>
#include <ntdef.h>

typedef NTSTATUS (NTAPI *pRtlInitUnicodeString)(PUNICODE_STRING,PCWSTR);
typedef NTSTATUS (NTAPI *pLdrLoadDll)(PWCHAR,ULONG,PUNICODE_STRING,PHANDLE);

typedef struct _THREAD_DATA
{
    pRtlInitUnicodeString fnRtlInitUnicodeString;
    pLdrLoadDll fnLdrLoadDll;
    UNICODE_STRING UnicodeString;
    WCHAR DllName[260];
    PWCHAR DllPath;
    ULONG Flags;
    HANDLE ModuleHandle;
}THREAD_DATA,*PTHREAD_DATA;

typedef struct _CLIENT_ID
{
     PVOID UniqueProcess;
     PVOID UniqueThread;
} CLIENT_ID, *PCLIENT_ID;

EXTERN_C NTSTATUS NTAPI RtlCreateUserThread(
HANDLE,
PSECURITY_DESCRIPTOR,
BOOLEAN,
ULONG,
PULONG,
PULONG,
PVOID,
PVOID,
PHANDLE,
PCLIENT_ID);

EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG,BOOLEAN,BOOLEAN,PBOOLEAN);
EXTERN_C NTSTATUS NTAPI NtOpenProcess(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES,PCLIENT_ID);
EXTERN_C NTSTATUS NTAPI NtWriteVirtualMemory(HANDLE,PVOID,PVOID,ULONG,PULONG);
EXTERN_C NTSTATUS NTAPI NtWaitForSingleObject(HANDLE,BOOLEAN,PLARGE_INTEGER);
EXTERN_C NTSTATUS NTAPI NtClose(HANDLE);

static HANDLE WINAPI ThreadProc(PTHREAD_DATA data)
{
    data->fnRtlInitUnicodeString(&data->UnicodeString,data->DllName);
    data->fnLdrLoadDll(data->DllPath,data->Flags,&data->UnicodeString,&data->ModuleHandle);
    return data->ModuleHandle;
}

static DWORD WINAPI dummy()
{
    return 0;
}

int main(int argc,char* argv[])
{
    THREAD_DATA data;
    OBJECT_ATTRIBUTES oa;
    CLIENT_ID cid;
    PROCESSENTRY32 pe32;

    HANDLE hProcess,hThread,hSnap;
    PVOID pData,code;
    BOOLEAN bl;
    DWORD dwExitCode;
    char str[260];

    pe32.dwSize=sizeof(pe32);

    if(argc==2)
    {
        if(!strcmp("proclist",argv[1]))
        {
            hSnap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);

            Process32First(hSnap,&pe32);

            printf("== Process name (PID) ==\n\n");

            while(Process32Next(hSnap,&pe32))
            {
                printf(" %s (%d)\n\n",pe32.szExeFile,pe32.th32ProcessID);
            }

            NtClose(hSnap);

            return 0;
        }
    }

    if(argc!=3)
    {
        printf("Usage: ldrcve [PID] [DLL name]\n\n");
        printf("ldrcve proclist - Display the list of running processes.\n\n");
        return 0;
    }

    memset(str,0,260);

    ULONG ulSizeOfCode=(LPBYTE)dummy-(LPBYTE)ThreadProc;

    HMODULE nt=GetModuleHandle("ntdll.dll");

    memcpy(str,argv[2],strlen(argv[2]));

    RtlAdjustPrivilege(20,TRUE,FALSE,&bl);
    MultiByteToWideChar(CP_ACP,0,str,260,data.DllName,260);

    cid.UniqueProcess=(HANDLE)atoi(argv[1]);
    cid.UniqueThread=0;

    data.fnRtlInitUnicodeString=(pRtlInitUnicodeString)GetProcAddress(nt,"RtlInitUnicodeString");
    data.fnLdrLoadDll=(pLdrLoadDll)GetProcAddress(nt,"LdrLoadDll");
    data.DllPath=NULL;
    data.Flags=0;

    InitializeObjectAttributes(&oa,NULL,0,NULL,NULL);

    printf("Opening process handle.\n\n");

    if(!NT_SUCCESS(NtOpenProcess(&hProcess,PROCESS_ALL_ACCESS,&oa,&cid)))
    {
        printf("Unable to open process handle.");
        return 1;
    }

    hSnap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);

    Process32First(hSnap,&pe32);

    while(Process32Next(hSnap,&pe32))
    {
        if(pe32.th32ProcessID==(DWORD)cid.UniqueProcess)
        {
            printf("Injecting codecave into %s process.\n\n",pe32.szExeFile);
        }
    }

    NtClose(hSnap);

    printf("Allocating memory in the target process.\n\n");

    pData=VirtualAllocEx(hProcess,NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    code=VirtualAllocEx(hProcess,NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);

    printf("Data address: %#x\n\n",pData);
    printf("Code address: %#x\n\n",code);

    printf("Writing thread data and code into target process.\n\n");

    NtWriteVirtualMemory(hProcess,pData,&data,sizeof(data),NULL);
    NtWriteVirtualMemory(hProcess,code,(PVOID)ThreadProc,ulSizeOfCode,NULL);

    printf("Creating remote thread in the target process.\n\n");

    if(!NT_SUCCESS(RtlCreateUserThread(hProcess,NULL,FALSE,0,0,0,code,pData,&hThread,NULL)))
    {
        printf("Unable to create remote thread in the target process.");
        NtClose(hProcess);
        return 1;
    }

    printf("Thread created. Now waiting for the thread to terminate.\n\n");

    NtWaitForSingleObject(hThread,FALSE,NULL);

    GetExitCodeThread(hThread,&dwExitCode);

    printf("Thread terminated. DLL address: %#x\n\n",dwExitCode);

    printf("Closing thread handle.\n\n");

    NtClose(hThread);

    printf("Freeing allocated memory.\n\n");

    VirtualFreeEx(hProcess,pData,0,MEM_RELEASE);
    VirtualFreeEx(hProcess,code,0,MEM_RELEASE);

    printf("Closing target process handle.");

    NtClose(hProcess);
    return 0;
}
